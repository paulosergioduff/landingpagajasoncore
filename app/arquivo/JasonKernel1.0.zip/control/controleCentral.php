<?php 

// Controladores booleanos para futura regra de negócios.

$controleSelectTotal = true; // Muito cuidado com a regra que vai colocar aqui
$controleSelect = true;
$controlDelete = true;
$controlInsert = true;
$controlUpdate = true;

	?>