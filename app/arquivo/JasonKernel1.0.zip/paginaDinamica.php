<?php
require_once('control/config.php');
if (file_exists("view/cabecalhoPadrao.html")) {
				include("view/cabecalhoPadrao.html");
}
if (file_exists("view/corpoPadrao.html")) {
				include("view/corpoPadrao.html");
}
?>