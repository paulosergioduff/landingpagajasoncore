<?php
include("conectar.php");

//http://www.sergiotoledo.com.br/tutoriais/mysql/comandos-basicos-de-mysql



echo "<h1>Exibir tabela inteira:</h1>";

 function exibirTodaTabela($tabela)
	{
		 $query = "SELECT * from $tabela";
    $result = mysql_query($query);
    while($fetch = mysql_fetch_row($result)){
        echo "<p>";
        foreach ($fetch as $value)
            echo $value . " - ";
        }

        echo "</p><hr>";
	}

	exibirTodaTabela('tabela');

echo "<h1>Exibir alguns campos:</h1>";

       function exibeCampos($tabela, $coluna1, $coluna2)
       			{
       				  $query = "SELECT * from $tabela";
       				  $result = mysql_query($query);
    					while($fetch = mysql_fetch_row($result)){
      				  echo "<p>". $fetch[$coluna1] . " - " . $fetch[$coluna2] . " - " . "</p>";
    															}
       			}

      exibeCampos('tabela', '0', '1');

echo "<hr>";

echo "<h1>Exibir alguns campos de um id:</h1>";

      function exibirCamposDeUmId($tabela, $coluna1, $coluna2, $procurarNoId)
       			{
       				  $query = "SELECT * from $tabela WHERE id = $procurarNoId";
       				  $result = mysql_query($query);
    					while($fetch = mysql_fetch_row($result)){
      				  echo "<p>". $fetch[$coluna1] . " - " . $fetch[$coluna2] . " - " . "</p>";
    															}
       			}

       			exibirCamposDeUmId('tabela', '1', '2', '5');

    ?>


