<?php

echo "Nossos Parceiros";

?>