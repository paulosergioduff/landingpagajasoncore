<?php 

//include "../model/miniCRUD.php";

$conteudo = file_get_contents("../model/miniCRUD.php");

echo $conteudo;

 //$saida = exibeCampos('tabela', '1', '2');

    ?>