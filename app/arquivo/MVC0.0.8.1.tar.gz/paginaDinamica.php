<?php 

require('control/config.php');

include ("view/cabecalhoPadrao.html") ;
include ("view/corpoPadrao.html") ;

?>

