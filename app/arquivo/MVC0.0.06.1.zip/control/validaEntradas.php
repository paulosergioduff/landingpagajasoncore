<?php

$categoria = 'PHP555';  
   $titulo  = 'Novo Insert';  
   $autor   = 'Duff'; 


/*  
    * Chama o método insert() e passa os parâmetros necessários  
    */  
  // $crud->insert($categoria, $titulo, $autor);   --> INSERT
  // $crud->update($categoria, $titulo, $autor, 02);--> UPDATE
  //$crud->delete(02)  ;------------------------------> DELETE
 //  $dados = $crud->getAlltabela(); ----------------->  SELECT (TODOS)
//
 
// IMPLEMENTAÇAÕ DE SELECTS
/*
//$dados = $crud->selecionaId(05); // OU 
//$dados = $crud->getAlltabela(); // para todos da tabela

    foreach ($dados as $reg):  
     echo "**********************************************
";  
     echo "Id: " . $reg->id . "
";   
     echo "Categoria: " . $reg->varchar1 . "
";  
     echo "Titulo: " . $reg->varchar2 . "
";  
   endforeach;  

 // $dados = $crud->getAlltabela();*/


   ?>