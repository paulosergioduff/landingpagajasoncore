<?php

$cabecalhoPadrao = "view/cabecalhoPadrao.html";
$corpoPadrao = "view/corpoPadrao.html";



?>