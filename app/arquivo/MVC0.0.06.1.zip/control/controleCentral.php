<?php 


$controleSelectTotal = true; // Muito cuidado com a regra que vai colocar aqui
$controleSelect = true;
$controlDelete = true;
$controlInsert = true;
$controlUpdate = true;

	?>