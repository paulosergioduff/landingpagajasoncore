<?php
include("conectar.php");

//$dado = "maria@email.com";
//$tabela = "tabela";

function apagar($dado, $tabela)
	{
		$cmd = "DELETE FROM $tabela WHERE varchar2 = '$dado'";
		$sql = mysql_query($cmd);
	}

	apagar('maria@email.com', 'tabela');


    ?>


