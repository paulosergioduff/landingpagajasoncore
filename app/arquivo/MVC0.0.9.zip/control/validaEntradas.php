<?php

$login = 'pauloduff23';  
$email  = 'email@mail.com';  
$senha   = '123456'; 
$tabela = "usuarios2"; // Insere último campo para tabela abstrata, para facilitar futura migração de dados
$valor1 = "valor1";
$valor2 = "Novo Valor";

$dbTabela = 'tabela'; // Indica ao CRUD, que tabela sofrerá alteração na query





   ?>