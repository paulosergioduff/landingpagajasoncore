<?php

$servidor = 'localhost';
$usuario  = 'root';
$senha    = 'root';
$banco    = 'abstrato';

$conecta = mysql_connect($servidor, $usuario, $senha);
mysql_select_db($banco);

function exibirTodaTabela($tabela)
{
    $query   = "SELECT * from $tabela";
    $resultado = mysql_query($query);
    while ($fetch = mysql_fetch_row($resultado)) {
        echo "<p>";
        foreach ($fetch as $value)
            echo $value . " - ";
    }
    
    // exibirTodaTabela('tabela');        
}

function exibeCampos($tabela, $coluna1, $coluna2)
{
    $query   = "SELECT * from $tabela";
    $resultado = mysql_query($query);
    while ($fetch = mysql_fetch_row($resultado)) {
        echo "<p>" . $fetch[$coluna1] . " - " . $fetch[$coluna2] . " - " . "</p>";
    }
    // exibeCampos('tabela', '0', '1');
}

exibirCamposDeUmId('tabela', '1', '2', '10');

function exibirCamposDeUmId($tabela, $coluna1, $coluna2, $procurarNoId)
{
    $query   = "SELECT * from $tabela WHERE id = $procurarNoId";
    $resultado = mysql_query($query);
    while ($fetch = mysql_fetch_row($resultado)) {
        echo "<p>" . $fetch[$coluna1] . " - " . $fetch[$coluna2] . " - " . "</p>";
    }
    // exibirCamposDeUmId('tabela', '1', '2', '5');
}

function atualizar($tabela, $campoAtual, $novoDado, $procurarNoId)
{
    $sql = mysql_query($query);
    // atualizar('tabela', 'varchar3', 'novasenha', '5');
}

function apagar($dado, $tabela)
{
    $query = "DELETE FROM $tabela WHERE id = '$dado'";
    $sql   = mysql_query($query);
    //apagar('4', 'tabela');
}

function insereDados($campo1, $campo2, $campo3, $campo4, $campo5, $dado1, $dado2, $dado3, $dado4, $dado5)
{
    
    $query = "INSERT INTO tabela ($campo1, $campo2, $campo3, $campo4, $campo5) VALUES ('$dado1', '$dado2', '$dado3', '$dado4', '$dado5' )";
    $sql   = mysql_query($query);
    
    // insereDados('varchar1', 'varchar2', 'varchar3', 'alias', 'tabela', 'hackeado', 'carlos@hotmail.com', 'abc123', 'login', 'cadastrados');
    
}

?>