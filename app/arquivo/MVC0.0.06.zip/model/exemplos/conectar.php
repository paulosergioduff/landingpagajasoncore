<?php
$host = 'localhost';
$user = 'root';
$pass = 'root';
$data = 'abstrato';

$conn = mysql_connect($host,$user,$pass);
 mysql_select_db($data);

 // agradecimentos ao site: http://www.sergiotoledo.com.br/tutoriais/mysql/comandos-basicos-de-mysql


?>