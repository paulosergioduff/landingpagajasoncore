<?php 

require('control/config.php');

include ($cabecalhoPadrao) ;
include ($corpoPadrao) ;

?>

