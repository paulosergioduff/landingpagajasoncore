 <?php 
   // Testando classe CRUD
   /*  
    * Require nos scripts necessários  
    */   
  require_once "../control/config.php";   
require_once "../control/validaEntradas.php";
require_once "../model/crud.class.php"; 
 
   /*  
    * Atribui uma instância da classe crud   
    * e passa uma conexão como parâmetro  
    */   
   $crud = crud::getInstance(Conexao::getInstance());
 
   /*  
    * Variáveis contendo os valores para serem inseridos no banco de dados  
    */  
  
  ?>


   