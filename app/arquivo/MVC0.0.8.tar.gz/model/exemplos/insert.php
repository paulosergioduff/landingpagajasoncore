<?php
include("conectar.php");


 //varchar1, varchar2, varchar3
//'Pedro Henrique', 'maria@email.com', 'abc123'

    function insereDados($campo1, $campo2, $campo3, $dado1, $dado2, $dado3)
    	{

   $cmd = "INSERT INTO tabela ($campo1, $campo2, $campo3) VALUES ('$dado1', '$dado2', '$dado3')";
    $sql = mysql_query($cmd);

    	}

    	insereDados('varchar1', 'varchar2', 'varchar3', 'Carlos Manuel', 'maria@email.com', 'abc123');
    ?>


