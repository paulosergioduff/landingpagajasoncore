function carregaModulos()
	{
		window.document.getElementById('topo').innerHTML = "NovoTopo2";
		window.document.getElementById('menuEsquerdo').innerHTML = "NovoMenuEsquerdo";
		window.document.getElementById('conteudo').innerHTML = "NovoConteudo";
		window.document.getElementById('menuDireito').innerHTML = "NovoMenuDireito";
		window.document.getElementById('rodape').innerHTML = "NovoRodape";
	}

	carregaModulos();

	