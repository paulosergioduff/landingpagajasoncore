<?php
include("conectar.php");

function atualizar($tabela, $campoAtual, $novoDado, $procurarNoId)

	{
		$cmd = "UPDATE $tabela SET $campoAtual = '$novoDado' WHERE id = $procurarNoId";
    	$sql = mysql_query($cmd);
	}

	atualizar('tabela', 'varchar3', '1234567890', '5');


    ?>


