<?php 

$arquivo = "teste.json";

$info = file_get_contents($arquivo);

$lendo = json_decode($info);

foreach($lendo->glossary as $campo){

echo "<b>Nome:</b> ".$campo->nome;
echo "<br /><b>login:</b> ".$campo->login;


}

?>