-- MySQL dump 10.16  Distrib 10.1.24-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u759271496_trirh
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cadastro`
--

DROP TABLE IF EXISTS `cadastro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cadastro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varchar1` varchar(255) NOT NULL,
  `varchar2` varchar(255) NOT NULL,
  `varchar3` varchar(255) NOT NULL,
  `varchar4` varchar(255) NOT NULL,
  `varchar5` varchar(255) NOT NULL,
  `num1` int(11) NOT NULL,
  `num2` int(11) NOT NULL,
  `num3` int(11) NOT NULL,
  `num4` int(11) NOT NULL,
  `num5` int(11) NOT NULL,
  `data1` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data2` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data3` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data4` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data5` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bit1` int(1) NOT NULL,
  `bit2` int(1) NOT NULL,
  `bit3` int(1) NOT NULL,
  `bit4` int(1) NOT NULL,
  `bit5` int(1) NOT NULL,
  `texto1` longtext NOT NULL,
  `texto2` longtext NOT NULL,
  `texto3` longtext NOT NULL,
  `texto4` longtext NOT NULL,
  `texto5` longtext NOT NULL,
  `alias` varchar(255) NOT NULL,
  `tabela` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cadastro`
--

/*!40000 ALTER TABLE `cadastro` DISABLE KEYS */;
INSERT INTO `cadastro` VALUES (1,'kkk6789','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'2017-05-28 21:27:06','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','','33333222usuario2'),(2,'kkk6789','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'2017-05-26 17:50:58','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','','kkk2usuario2'),(3,'kkk6789','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'2017-05-26 17:51:11','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','','kkk2usuario2'),(4,'kkk6789','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'2017-05-26 18:34:34','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','','kkk2usuario2'),(5,'kkk6789','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'2017-05-26 18:41:02','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','','kkk2usuario2');
/*!40000 ALTER TABLE `cadastro` ENABLE KEYS */;

--
-- Table structure for table `conteudo`
--

DROP TABLE IF EXISTS `conteudo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conteudo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varchar1` varchar(255) NOT NULL,
  `varchar2` varchar(255) NOT NULL,
  `varchar3` varchar(255) NOT NULL,
  `varchar4` varchar(255) NOT NULL,
  `varchar5` varchar(255) NOT NULL,
  `num1` int(11) NOT NULL,
  `num2` int(11) NOT NULL,
  `num3` int(11) NOT NULL,
  `num4` int(11) NOT NULL,
  `num5` int(11) NOT NULL,
  `data1` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data2` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data3` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data4` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data5` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bit1` int(1) NOT NULL,
  `bit2` int(1) NOT NULL,
  `bit3` int(1) NOT NULL,
  `bit4` int(1) NOT NULL,
  `bit5` int(1) NOT NULL,
  `texto1` longtext NOT NULL,
  `texto2` longtext NOT NULL,
  `texto3` longtext NOT NULL,
  `texto4` longtext NOT NULL,
  `texto5` longtext NOT NULL,
  `alias` varchar(255) NOT NULL,
  `tabela` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conteudo`
--

/*!40000 ALTER TABLE `conteudo` DISABLE KEYS */;
INSERT INTO `conteudo` VALUES (1,'Novo título da página Redirec','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(2,'Triangular RH - Lapidando Talentos Humanos.','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(3,'Soluções customizadas em Recursos Humanos ','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(4,'Se o mercado exige mais, seja Triangular RH. ','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(5,'RECRUTAMENTO E SELEÇÃO','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(6,'CONSULTORIA DE RH','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(7,'TREINAMENTOS E CURSOS','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(8,'Deseja contratar Talentos Humanos? Sua empresa encontra-se com grande rotatividade de colaboradores? Temos a satisfação de otimizar sua empresa na Seleção de Pessoal.','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(9,'Planeja organizar sua empresa, obter uma equipe motivada e retorno dos serviços com qualidade? Desenvolvemos, implantamos e viabilizamos o projeto da necessidade de sua empresa.','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(10,'-Deseja atitude através da aquisição de novas habilidades e conhecimentos e quer ter uma equipe motivada que produza resultados de crescimento e avanços para sua organização?  Quer se qualificar e aprimorar para o mercado de trabalho? Temos cursos livres.','kkkkandoNovoDadoInserido','kkkil@gmailc.om','kkkSmais1@mail.com','kkkkkalor',0,0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','','');
/*!40000 ALTER TABLE `conteudo` ENABLE KEYS */;

--
-- Table structure for table `membros`
--

DROP TABLE IF EXISTS `membros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(12) NOT NULL,
  `senha` varchar(60) NOT NULL,
  `permissao` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membros`
--

/*!40000 ALTER TABLE `membros` DISABLE KEYS */;
INSERT INTO `membros` VALUES (1,'root','$2a$08$Cf1f11ePArKlBJomM0F6a.h04ineyy1Mjfw3Ys2A8v3XoPG2NEzEC','admin');
/*!40000 ALTER TABLE `membros` ENABLE KEYS */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(16) NOT NULL,
  `link` varchar(255) NOT NULL,
  `hover` varchar(11) NOT NULL,
  `class` varchar(16) NOT NULL,
  `tagInicio` varchar(32) NOT NULL,
  `tagFim` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'Menu1','','','','<ul>',''),(2,'opcao1','','','','<li>','</li>'),(3,'opcao2','','','','<li>','</li>'),(4,'opcao3','','','','<li>','</li></ul>'),(5,'menu2','','','','<ul>',''),(6,'opcao1','','','','<li>','</li>'),(7,'opcao2','','','','<li>','</li>'),(8,'opcao3','','','','<li>','</li>');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;

--
-- Table structure for table `opcoes`
--

DROP TABLE IF EXISTS `opcoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opcoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `opcao` varchar(16) NOT NULL,
  `link` varchar(255) NOT NULL,
  `hover` varchar(11) NOT NULL,
  `class` varchar(16) NOT NULL,
  `menu` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opcoes`
--

/*!40000 ALTER TABLE `opcoes` DISABLE KEYS */;
INSERT INTO `opcoes` VALUES (0,'yahoo','www.yahoo.com.br','','','1'),(1,'google','www.google.com','','','1'),(3,'microsoft','','','','2');
/*!40000 ALTER TABLE `opcoes` ENABLE KEYS */;

--
-- Table structure for table `tabela`
--

DROP TABLE IF EXISTS `tabela`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabela` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varchar1` varchar(255) CHARACTER SET utf8 NOT NULL,
  `varchar2` varchar(255) CHARACTER SET utf8 NOT NULL,
  `varchar3` varchar(255) CHARACTER SET utf8 NOT NULL,
  `varchar4` varchar(255) CHARACTER SET utf8 NOT NULL,
  `varchar5` varchar(255) CHARACTER SET utf8 NOT NULL,
  `num1` int(11) NOT NULL,
  `num2` int(11) NOT NULL,
  `num3` int(11) NOT NULL,
  `num4` int(11) NOT NULL,
  `num5` int(11) NOT NULL,
  `data1` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data2` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data3` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data4` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data5` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bit1` int(1) NOT NULL,
  `bit2` int(1) NOT NULL,
  `bit3` int(1) NOT NULL,
  `bit4` int(1) NOT NULL,
  `bit5` int(1) NOT NULL,
  `texto1` longtext CHARACTER SET utf8 NOT NULL,
  `texto2` longtext CHARACTER SET utf8 NOT NULL,
  `texto3` longtext CHARACTER SET utf8 NOT NULL,
  `texto4` longtext CHARACTER SET utf8 NOT NULL,
  `texto5` longtext CHARACTER SET utf8 NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 NOT NULL,
  `tabela` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabela`
--

/*!40000 ALTER TABLE `tabela` DISABLE KEYS */;
INSERT INTO `tabela` VALUES (5,'Pedro Henrique','maria@email.com','novasenha','','',0,0,0,0,0,'2017-03-25 02:19:19','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(7,'Carlos Manuel','carlos@hotmail.com','abc1234','','',0,0,0,0,0,'2017-03-25 02:26:26','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(8,'Carlos Manuel2','carlos@hotmail.com','abc1234','','',0,0,0,0,0,'2017-03-25 02:27:22','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(9,'Novo Manuel','carlos@hotmail.com','abc123','','',0,0,0,0,0,'2017-03-25 03:02:46','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','',''),(10,'hackeado','carlos@hotmail.com','abc123','','',0,0,0,0,0,'2017-03-25 03:08:11','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0,0,'','','','','','login','cadastrados');
/*!40000 ALTER TABLE `tabela` ENABLE KEYS */;

--
-- Dumping events for database 'u759271496_trirh'
--

--
-- Dumping routines for database 'u759271496_trirh'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-07 14:37:21
